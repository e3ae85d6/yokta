// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int copy_toast_gravity_offset = 0x7f060000;
    public static final int copy_toast_horizontal_margin = 0x7f060001;
    public static final int copy_toast_vertical_margin = 0x7f060002;

    public ()
    {
    }
}
