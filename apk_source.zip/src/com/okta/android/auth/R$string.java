// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int app_name = 0x7f070000;
    public static final int app_name_short = 0x7f070001;
    public static final int code_copied_to_clipboard = 0x7f070002;
    public static final int copy_hint = 0x7f070003;
    public static final int enter_account_activity_title = 0x7f070004;
    public static final int enter_account_cancel_label = 0x7f070005;
    public static final int enter_account_error_parse_uri = 0x7f070006;
    public static final int enter_account_error_secret_decode = 0x7f070007;
    public static final int enter_account_error_secret_empty = 0x7f070008;
    public static final int enter_account_error_secret_invalid_char = 0x7f070009;
    public static final int enter_account_error_secret_too_short = 0x7f07000a;
    public static final int enter_account_error_username_empty = 0x7f07000b;
    public static final int enter_account_name_hint = 0x7f07000c;
    public static final int enter_account_name_label = 0x7f07000d;
    public static final int enter_account_save_label = 0x7f07000e;
    public static final int enter_account_secret_hint = 0x7f07000f;
    public static final int enter_account_secret_hint_unmodified = 0x7f070010;
    public static final int enter_account_secret_label = 0x7f070011;
    public static final int information_barcode_help_text = 0x7f070012;
    public static final int information_diag_account_uris = 0x7f070013;
    public static final int information_diag_countdown = 0x7f070014;
    public static final int information_diag_current_interval = 0x7f070015;
    public static final int information_diag_interval = 0x7f070016;
    public static final int information_diag_name = 0x7f070017;
    public static final int information_diag_not_set = 0x7f070018;
    public static final int information_diag_pin = 0x7f070019;
    public static final int information_diag_reset = 0x7f07001a;
    public static final int information_diag_title = 0x7f07001b;
    public static final int information_diag_uris = 0x7f07001c;
    public static final int information_help_button = 0x7f07001d;
    public static final int information_help_text = 0x7f07001e;
    public static final int information_help_title = 0x7f07001f;
    public static final int information_legal_button = 0x7f070020;
    public static final int information_legal_html_file = 0x7f070021;
    public static final int information_legal_title = 0x7f070022;
    public static final int information_title = 0x7f070023;
    public static final int information_version = 0x7f070024;
    public static final int initial_setup_intro_text = 0x7f070025;
    public static final int install_barcode_confirm = 0x7f070026;
    public static final int install_barcode_deny = 0x7f070027;
    public static final int install_barcode_message = 0x7f070028;
    public static final int install_barcode_title = 0x7f070029;
    public static final int manage_account_enter_manually = 0x7f07002a;
    public static final int manage_account_error_parse_uri = 0x7f07002b;
    public static final int manage_account_scan_barcode = 0x7f07002c;
    public static final int manage_account_success_parse_uri = 0x7f07002d;
    public static final int manage_account_text = 0x7f07002e;
    public static final int manage_account_title = 0x7f07002f;

    public ()
    {
    }
}
