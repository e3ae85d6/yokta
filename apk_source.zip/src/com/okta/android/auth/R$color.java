// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int background_dark_gradient_end_color = 0x7f040000;
    public static final int background_dark_gradient_start_color = 0x7f040001;
    public static final int background_light_gradient_end_color = 0x7f040002;
    public static final int background_light_gradient_start_color = 0x7f040003;
    public static final int black = 0x7f040004;
    public static final int blue = 0x7f040005;
    public static final int code_copy_text_color = 0x7f040006;
    public static final int code_progress_color = 0x7f040007;
    public static final int code_progress_expired_color = 0x7f040008;
    public static final int green = 0x7f040009;
    public static final int okta_logo_background_end_color = 0x7f04000a;
    public static final int okta_logo_background_start_color = 0x7f04000b;
    public static final int okta_logo_background_stroke = 0x7f04000c;
    public static final int okta_logo_inner_shadow = 0x7f04000d;
    public static final int okta_logo_outer_shadow = 0x7f04000e;
    public static final int okta_logo_progress = 0x7f04000f;
    public static final int red = 0x7f040010;
    public static final int toolbar_button_normal_end_color = 0x7f040011;
    public static final int toolbar_button_normal_start_color = 0x7f040012;
    public static final int toolbar_button_pressed_end_color = 0x7f040013;
    public static final int toolbar_button_pressed_start_color = 0x7f040014;
    public static final int toolbar_gradient_end_color = 0x7f040015;
    public static final int toolbar_gradient_start_color = 0x7f040016;
    public static final int toolbar_inner_line_color = 0x7f040017;
    public static final int toolbar_inner_shadow_color = 0x7f040018;
    public static final int toolbar_outer_line_color = 0x7f040019;
    public static final int toolbar_outer_shadow_color = 0x7f04001a;
    public static final int transparent = 0x7f04001b;
    public static final int validation_error = 0x7f04001c;
    public static final int white = 0x7f04001d;

    public ()
    {
    }
}
