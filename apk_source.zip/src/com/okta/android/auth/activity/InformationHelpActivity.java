// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.activity;

import android.os.Bundle;

// Referenced classes of package com.okta.android.auth.activity:
//            InformationSectionActivity

public class InformationHelpActivity extends InformationSectionActivity
{

    public InformationHelpActivity()
    {
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setToolbarTitle(0x7f07001f);
        setHtml(0x7f07001e);
    }
}
