// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

// Referenced classes of package com.okta.android.auth.activity:
//            SecureActivity, CodeActivity, InformationActivity, ManageAccountActivity

public class ToolbarActivity extends SecureActivity
    implements android.view.View.OnClickListener
{

    private ViewGroup mChildContainer;
    private boolean mContentViewReady;
    private ImageButton mHomeButton;
    private ImageView mIconView;
    private ImageButton mInfoButton;
    private boolean mResumed;
    private View mRootView;
    private ImageButton mSettingsButton;
    private TextView mTitleText;

    public ToolbarActivity()
    {
        mContentViewReady = false;
        mResumed = false;
    }

    private void checkContentView()
    {
        if (!mContentViewReady)
        {
            throw new IllegalStateException("Content view is not set. Call super.onCreate() first!");
        } else
        {
            return;
        }
    }

    protected ViewGroup getChildContainerView()
    {
        return mChildContainer;
    }

    protected View getRootView()
    {
        return mRootView;
    }

    protected ImageButton getToolbarButton(ButtonType buttontype)
    {
        switch (_cls1..SwitchMap.com.okta.android.auth.activity.ToolbarActivity.ButtonType[buttontype.ordinal()])
        {
        default:
            throw new IllegalArgumentException((new StringBuilder()).append("Button type ").append(buttontype.name()).append(" is not supprted.").toString());

        case 1: // '\001'
            return mHomeButton;

        case 2: // '\002'
            return mSettingsButton;

        case 3: // '\003'
            return mInfoButton;
        }
    }

    protected ImageView getToolbarIconView()
    {
        return mIconView;
    }

    protected TextView getToolbarTitleView()
    {
        return mTitleText;
    }

    protected void hideToolbarButtons()
    {
        ButtonType abuttontype[] = ButtonType.values();
        int i = abuttontype.length;
        for (int j = 0; j < i; j++)
        {
            getToolbarButton(abuttontype[j]).setVisibility(8);
        }

    }

    protected transient void hideToolbarButtons(ButtonType abuttontype[])
    {
        int i = abuttontype.length;
        for (int j = 0; j < i; j++)
        {
            getToolbarButton(abuttontype[j]).setVisibility(8);
        }

    }

    public boolean isActivityResumed()
    {
        return mResumed;
    }

    public void onClick(View view)
    {
        if (view == mHomeButton)
        {
            onToolbarButtonClicked(ButtonType.HOME);
        } else
        {
            if (view == mSettingsButton)
            {
                onToolbarButtonClicked(ButtonType.SETTINGS);
                return;
            }
            if (view == mInfoButton)
            {
                onToolbarButtonClicked(ButtonType.INFO);
                return;
            }
        }
    }

    protected void onCreate(Bundle bundle)
    {
        getWindow().setFormat(1);
        getWindow().addFlags(4096);
        super.onCreate(bundle);
        getWindow().requestFeature(1);
        super.setContentView(0x7f030008);
        mContentViewReady = true;
        mRootView = findViewById(0x7f080023);
        mChildContainer = (ViewGroup)findViewById(0x7f080029);
        mIconView = (ImageView)findViewById(0x7f080024);
        mTitleText = (TextView)findViewById(0x7f080025);
        mHomeButton = (ImageButton)findViewById(0x7f080026);
        mSettingsButton = (ImageButton)findViewById(0x7f080027);
        mInfoButton = (ImageButton)findViewById(0x7f080028);
        mHomeButton.setOnClickListener(this);
        mSettingsButton.setOnClickListener(this);
        mInfoButton.setOnClickListener(this);
        mIconView.setVisibility(8);
        mTitleText.setText("");
        mHomeButton.setVisibility(8);
        mSettingsButton.setVisibility(8);
        mInfoButton.setVisibility(8);
    }

    protected void onHomeClicked()
    {
        CodeActivity.openAsHome(this);
    }

    protected void onInfoClicked()
    {
        startActivity(new Intent(this, com/okta/android/auth/activity/InformationActivity));
    }

    protected void onPause()
    {
        super.onPause();
        mResumed = false;
    }

    protected void onResume()
    {
        super.onResume();
        mResumed = true;
    }

    protected void onSettingsClicked()
    {
        startActivity(new Intent(this, com/okta/android/auth/activity/ManageAccountActivity));
    }

    protected void onToolbarButtonClicked(ButtonType buttontype)
    {
        switch (_cls1..SwitchMap.com.okta.android.auth.activity.ToolbarActivity.ButtonType[buttontype.ordinal()])
        {
        default:
            return;

        case 1: // '\001'
            onHomeClicked();
            return;

        case 2: // '\002'
            onSettingsClicked();
            return;

        case 3: // '\003'
            onInfoClicked();
            break;
        }
    }

    protected void setChildBackgroundColor(int i)
    {
        mRootView.setBackgroundColor(i);
    }

    protected void setChildBackgroundDrawable(Drawable drawable)
    {
        mRootView.setBackgroundDrawable(drawable);
    }

    protected void setChildBackgroundResource(int i)
    {
        mRootView.setBackgroundResource(i);
    }

    public void setContentView(int i)
    {
        View view = LayoutInflater.from(this).inflate(i, mChildContainer, false);
        mChildContainer.removeAllViews();
        mChildContainer.addView(view);
    }

    public void setContentView(View view)
    {
        mChildContainer.removeAllViews();
        mChildContainer.addView(view);
    }

    public void setContentView(View view, android.view.ViewGroup.LayoutParams layoutparams)
    {
        mChildContainer.removeAllViews();
        mChildContainer.addView(view, layoutparams);
    }

    protected void setToolbarIcon(int i)
    {
        showToolbarIcon();
        mIconView.setImageResource(i);
    }

    protected void setToolbarTitle(int i)
    {
        setToolbarTitle(getResources().getString(i));
    }

    protected void setToolbarTitle(String s)
    {
        checkContentView();
        mTitleText.setText(s);
    }

    protected void showToolbarButtons()
    {
        ButtonType abuttontype[] = ButtonType.values();
        int i = abuttontype.length;
        for (int j = 0; j < i; j++)
        {
            getToolbarButton(abuttontype[j]).setVisibility(0);
        }

    }

    protected transient void showToolbarButtons(ButtonType abuttontype[])
    {
        int i = abuttontype.length;
        for (int j = 0; j < i; j++)
        {
            getToolbarButton(abuttontype[j]).setVisibility(0);
        }

    }

    protected void showToolbarIcon()
    {
        mIconView.setVisibility(0);
    }

    private class _cls1
    {

        static final int $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[];

        static 
        {
            $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType = new int[ButtonType.values().length];
            try
            {
                $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ButtonType.HOME.ordinal()] = 1;
            }
            catch (NoSuchFieldError nosuchfielderror) { }
            try
            {
                $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ButtonType.SETTINGS.ordinal()] = 2;
            }
            catch (NoSuchFieldError nosuchfielderror1) { }
            try
            {
                $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ButtonType.INFO.ordinal()] = 3;
            }
            catch (NoSuchFieldError nosuchfielderror2)
            {
                return;
            }
        }
    }


    private class ButtonType extends Enum
    {

        private static final ButtonType $VALUES[];
        public static final ButtonType HOME;
        public static final ButtonType INFO;
        public static final ButtonType SETTINGS;

        public static ButtonType valueOf(String s)
        {
            return (ButtonType)Enum.valueOf(com/okta/android/auth/activity/ToolbarActivity$ButtonType, s);
        }

        public static ButtonType[] values()
        {
            return (ButtonType[])$VALUES.clone();
        }

        static 
        {
            HOME = new ButtonType("HOME", 0);
            SETTINGS = new ButtonType("SETTINGS", 1);
            INFO = new ButtonType("INFO", 2);
            ButtonType abuttontype[] = new ButtonType[3];
            abuttontype[0] = HOME;
            abuttontype[1] = SETTINGS;
            abuttontype[2] = INFO;
            $VALUES = abuttontype;
        }

        private ButtonType(String s, int i)
        {
            super(s, i);
        }
    }

}
