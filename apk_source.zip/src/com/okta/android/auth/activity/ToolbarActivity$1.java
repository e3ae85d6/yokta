// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.activity;


class ttonType
{

    static final int $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[];

    static 
    {
        $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType = new int[ttonType.values().length];
        try
        {
            $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ttonType.HOME.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror) { }
        try
        {
            $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ttonType.SETTINGS.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$okta$android$auth$activity$ToolbarActivity$ButtonType[ttonType.INFO.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2)
        {
            return;
        }
    }
}
