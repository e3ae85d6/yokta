// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.activity;


public final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES HOME;
    public static final .VALUES INFO;
    public static final .VALUES SETTINGS;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/okta/android/auth/activity/ToolbarActivity$ButtonType, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        HOME = new <init>("HOME", 0);
        SETTINGS = new <init>("SETTINGS", 1);
        INFO = new <init>("INFO", 2);
        e_3B_.clone aclone[] = new <init>[3];
        aclone[0] = HOME;
        aclone[1] = SETTINGS;
        aclone[2] = INFO;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
