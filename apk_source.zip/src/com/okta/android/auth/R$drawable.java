// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int actionbar_account = 0x7f020000;
    public static final int actionbar_home = 0x7f020001;
    public static final int actionbar_info = 0x7f020002;
    public static final int button_manual_entry = 0x7f020003;
    public static final int button_scan_code = 0x7f020004;
    public static final int button_transparent = 0x7f020005;
    public static final int dark_background = 0x7f020006;
    public static final int launch_icon = 0x7f020007;
    public static final int light_background = 0x7f020008;
    public static final int list_diagnostics = 0x7f020009;
    public static final int list_help = 0x7f02000a;
    public static final int list_legal = 0x7f02000b;
    public static final int list_next = 0x7f02000c;
    public static final int okta_icon = 0x7f02000d;
    public static final int okta_logo = 0x7f02000e;
    public static final int toolbar_background = 0x7f02000f;
    public static final int toolbar_button_background = 0x7f020010;
    public static final int toolbar_button_normal_background = 0x7f020011;
    public static final int toolbar_button_pressed_background = 0x7f020012;
    public static final int validated_background = 0x7f020013;

    public ()
    {
    }
}
