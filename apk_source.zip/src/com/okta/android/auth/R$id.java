// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int account_name = 0x7f080003;
    public static final int accounts = 0x7f080009;
    public static final int cancel = 0x7f080014;
    public static final int child = 0x7f080029;
    public static final int container = 0x7f08000a;
    public static final int copy_hint_view = 0x7f080002;
    public static final int countdown = 0x7f080007;
    public static final int current_inteval = 0x7f080005;
    public static final int descr = 0x7f080020;
    public static final int diag = 0x7f08001d;
    public static final int diag_layout = 0x7f08001c;
    public static final int help = 0x7f08001a;
    public static final int home = 0x7f080026;
    public static final int icon = 0x7f080024;
    public static final int info = 0x7f080028;
    public static final int interval = 0x7f080006;
    public static final int legal = 0x7f08001b;
    public static final int manual = 0x7f080022;
    public static final int name = 0x7f080000;
    public static final int pin = 0x7f080004;
    public static final int progress = 0x7f080001;
    public static final int reset = 0x7f080008;
    public static final int root = 0x7f080023;
    public static final int save = 0x7f080013;
    public static final int scan = 0x7f080021;
    public static final int secret = 0x7f080011;
    public static final int secret_label = 0x7f08000f;
    public static final int secret_status = 0x7f080012;
    public static final int secret_status_wrapper = 0x7f080019;
    public static final int secret_validation_layout = 0x7f080010;
    public static final int secret_wrapper = 0x7f080017;
    public static final int settings = 0x7f080027;
    public static final int spacer = 0x7f080018;
    public static final int text = 0x7f08001f;
    public static final int title = 0x7f080025;
    public static final int username = 0x7f08000d;
    public static final int username_label = 0x7f08000b;
    public static final int username_status = 0x7f08000e;
    public static final int username_status_wrapper = 0x7f080016;
    public static final int username_validation_layout = 0x7f08000c;
    public static final int username_wrapper = 0x7f080015;
    public static final int version = 0x7f08001e;

    public ()
    {
    }
}
