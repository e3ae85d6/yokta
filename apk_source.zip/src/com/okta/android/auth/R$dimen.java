// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int activity_frame_width = 0x7f050000;
    public static final int button_side_padding = 0x7f050001;
    public static final int information_button_height = 0x7f050002;
    public static final int large = 0x7f050003;
    public static final int medium = 0x7f050004;
    public static final int okta_logo_inner_shadow = 0x7f050005;
    public static final int okta_logo_outer_shadow = 0x7f050006;
    public static final int okta_logo_stroke = 0x7f050007;
    public static final int small = 0x7f050008;
    public static final int toolbar_button_width = 0x7f050009;
    public static final int toolbar_height = 0x7f05000a;
    public static final int toolbar_one_line = 0x7f05000b;
    public static final int toolbar_three_lines = 0x7f05000c;
    public static final int toolbar_two_lines = 0x7f05000d;
    public static final int xlarge = 0x7f05000e;
    public static final int xsmall = 0x7f05000f;

    public ()
    {
    }
}
