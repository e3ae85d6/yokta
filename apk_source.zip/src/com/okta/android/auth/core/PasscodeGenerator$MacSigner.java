// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.core;

import com.a.a.a.a;
import javax.crypto.Mac;

public class mMac
    implements mMac
{

    private final Mac mMac;

    public byte[] sign(byte abyte0[])
    {
        return mMac.doFinal(abyte0);
    }

    public (Mac mac)
    {
        a.a(mac, "MAC can not be null");
        mMac = mac;
    }
}
