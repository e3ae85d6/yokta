// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.core;

import com.a.a.a.a;

public class PasscodeClock
{

    public static final int DEFAULT_STEP = 30;
    private final int mStep;

    public PasscodeClock()
    {
        mStep = 30;
    }

    public PasscodeClock(int i)
    {
        boolean flag;
        Object aobj[];
        if (i > 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        aobj = new Object[1];
        aobj[0] = Integer.valueOf(i);
        a.a(flag, "Invalid passcode clock step: %d.", aobj);
        mStep = i;
    }

    public long getCurrentInterval()
    {
        return getInterval(System.currentTimeMillis());
    }

    public long getInterval(long l)
    {
        return l / 1000L / (long)mStep;
    }

    public int getStep()
    {
        return mStep;
    }

    public long getTime(long l)
    {
        return 1000L * (l * (long)mStep);
    }
}
