// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth;


public final class 
{

    public static final int code = 0x7f030000;
    public static final int diagnostics = 0x7f030001;
    public static final int diagnostics_account_uris = 0x7f030002;
    public static final int enter_account = 0x7f030003;
    public static final int focus_catcher = 0x7f030004;
    public static final int information = 0x7f030005;
    public static final int information_section = 0x7f030006;
    public static final int manage_account = 0x7f030007;
    public static final int toolbar_master_page = 0x7f030008;

    public ()
    {
    }
}
