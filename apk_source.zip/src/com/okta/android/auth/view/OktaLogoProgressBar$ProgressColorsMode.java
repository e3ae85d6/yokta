// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.okta.android.auth.view;


public final class  extends Enum
{

    private static final .VALUES $VALUES[];
    public static final .VALUES ColorOnTransparent;
    public static final .VALUES TransparentOnColor;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(com/okta/android/auth/view/OktaLogoProgressBar$ProgressColorsMode, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        ColorOnTransparent = new <init>("ColorOnTransparent", 0);
        TransparentOnColor = new <init>("TransparentOnColor", 1);
        e_3B_.clone aclone[] = new <init>[2];
        aclone[0] = ColorOnTransparent;
        aclone[1] = TransparentOnColor;
        $VALUES = aclone;
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
